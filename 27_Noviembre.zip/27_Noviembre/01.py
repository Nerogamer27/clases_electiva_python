nombre="Antonio"
edad=18
edad=20
print("Hola",nombre,"Tu edad es ",edad)