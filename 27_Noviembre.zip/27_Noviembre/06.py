a=int(input("Ingrese el primer número: "))
b=int(input("Ingrese el segundo número: "))
if a>b:
    print(f"{a} Es mayor que {b}")
else:
    print(f"{b} Es mayor que {a}")