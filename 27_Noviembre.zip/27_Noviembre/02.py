nombre=input("Escribe tu nombre: ")
print("Bienvenid@",nombre)