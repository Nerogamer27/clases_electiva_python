nota=float(input("Digite su nota: "))
if nota>=4.5:
    print("Excelente")
elif nota>=3.0:
    print("Aprobado")
else:
    print("Reprobado")