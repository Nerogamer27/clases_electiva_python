edad=int(input("Ingrese su edad: "))
if edad<=11:
    print("Usted es un niño")
elif edad>=12 and edad<=17:
    print("Usted es un adolescente")
elif edad>=18:
    print("Usted es un adulto")