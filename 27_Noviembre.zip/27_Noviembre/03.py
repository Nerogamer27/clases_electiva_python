a=int(input("Ingresa el primer número: "))
b=int(input("Ingresa el segundo número: "))
print(f"{a} El resultado de {a} + {b} es: {a+b}")