i=0
palabra=str(input("Ingresa una palabra: "))
n=int(input("Ingresa un número: "))
while i<n: 
    print(palabra)
    i+=1