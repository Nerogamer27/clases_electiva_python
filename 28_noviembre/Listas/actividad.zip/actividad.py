#8 frutas, mostrar la quinta y cambiar la ultima#
fruta=["Manzana","Banana","Cereza","Durazno","Fresa","Mango","Naranja","Pera","Uva"]
fruta[8]="Guanabana"
print(fruta)
print("---------------------------")
print(fruta[5])
print("--------Actividad 2--------")
estudiante={"nombre": "Antonio", "edad": 18, "grado": "Decimo"}
estudiante["ciudad"]="Neiva"
print(estudiante)
print(estudiante["edad"])